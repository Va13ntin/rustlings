// variables6.rs
//
// Execute `rustlings hint variables6` or use the `hint` watch subcommand for a
// hint.
///ajout du type i32 a la constante NUMBER pour spécifier que c'est un entier de 32 bits

const NUMBER: i32 = 3;
fn main() {
    println!("Number {}", NUMBER);
}
